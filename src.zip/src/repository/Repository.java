package repository;

import model.state.ProgramState;

public interface Repository {
    void addProgramState(ProgramState program);
    ProgramState getCurrentState();
}
