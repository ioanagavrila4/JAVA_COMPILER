package model.statement;

import model.expression.Expression;
import model.state.ProgramState;
import model.type.Type;
import model.value.BoolValue;
import model.value.Value;

public record IfStatement(Expression condition, Statement thenStatement, Statement elseStatement) implements Statement {

    @Override
    public ProgramState execute(ProgramState state) {
        Value value = condition.evaluate(state.symbolTable());
        if (value.getType() != Type.BOOLEAN) {
            throw new RuntimeException("If condition is not boolean");
        }

        BoolValue booleanValue = (BoolValue) value;
        Statement chosenStatement = booleanValue.value() ?
                thenStatement : elseStatement;
        state.executionStack().push(chosenStatement);
        return state;
    }

    @Override
    public String toString() {
        return "(IF(" + condition.toString() + ") THEN(" + thenStatement.toString() +
                ")ELSE(" + elseStatement.toString() + "))";
    }
}
