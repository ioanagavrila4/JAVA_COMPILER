import view.TextMenu;

void main() {
    TextMenu menu = new TextMenu();
    menu.start();
}