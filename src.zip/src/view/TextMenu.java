package view;

import controller.Controller;
import model.expression.*;
import model.statement.*;
import model.type.Type;
import model.value.BoolValue;
import model.value.IntValue;
import repository.ArrayListRepository;
import repository.Repository;

import java.util.Scanner;

public class TextMenu {
    private final Scanner scanner;

    public TextMenu() {
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            printMenu();
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    runExample1();
                    break;
                case "2":
                    runExample2();
                    break;
                case "3":
                    runExample3();
                    break;
                case "0":
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private void printMenu() {
        System.out.println("\n=== Toy Language Interpreter ===");
        System.out.println("1. Run Example 1: int v; v=2; Print(v)");
        System.out.println("2. Run Example 2: int a; a=2+3*5; int b; b=a-4/2+7; Print(b)");
        System.out.println("3. Run Example 3: bool a; a=false; int v; If a Then v=2 Else v=3; Print(v)");
        System.out.println("0. Exit");
    }

    private void runExample1() {
        System.out.println("\n--- Running Example 1 ---");
        Statement ex1 = new CompoundStatement(
                new VariableDeclarationStatement(Type.INTEGER, "v"),
                new CompoundStatement(
                        new AssignmentStatement("v", new ValueExpression(new IntValue(2))),
                        new PrintStatement(new VariableExpression("v"))));

        executeProgram(ex1);
    }

    private void runExample2() {
        System.out.println("\n--- Running Example 2 ---");
        Statement ex2 = new CompoundStatement(
                new VariableDeclarationStatement(Type.INTEGER, "a"),
                new CompoundStatement(
                        new VariableDeclarationStatement(Type.INTEGER, "b"),
                        new CompoundStatement(
                                new AssignmentStatement("a",
                                        new ArithmeticExpression(
                                                new ValueExpression(new IntValue(2)),
                                                new ArithmeticExpression(
                                                        new ValueExpression(new IntValue(3)),
                                                        new ValueExpression(new IntValue(5)),
                                                        '*'),
                                                '+')),
                                new CompoundStatement(
                                        new AssignmentStatement("b",
                                                new ArithmeticExpression(
                                                        new ArithmeticExpression(
                                                                new VariableExpression("a"),
                                                                new ArithmeticExpression(
                                                                        new ValueExpression(new IntValue(4)),
                                                                        new ValueExpression(new IntValue(2)),
                                                                        '/'),
                                                                '-'),
                                                        new ValueExpression(new IntValue(7)),
                                                        '+')),
                                        new PrintStatement(new VariableExpression("b"))))));

        executeProgram(ex2);
    }

    private void runExample3() {
        System.out.println("\n--- Running Example 3 ---");
        Statement ex3 = new CompoundStatement(
                new VariableDeclarationStatement(Type.BOOLEAN, "a"),
                new CompoundStatement(
                        new VariableDeclarationStatement(Type.INTEGER, "v"),
                        new CompoundStatement(
                                new AssignmentStatement("a", new ValueExpression(new BoolValue(false))),
                                new CompoundStatement(
                                        new IfStatement(
                                                new VariableExpression("a"),
                                                new AssignmentStatement("v", new ValueExpression(new IntValue(2))),
                                                new AssignmentStatement("v", new ValueExpression(new IntValue(3)))),
                                        new PrintStatement(new VariableExpression("v"))))));

        executeProgram(ex3);
    }

    private void executeProgram(Statement program) {
        Repository repository = new ArrayListRepository();
        Controller controller = new Controller(repository);
        controller.addNewProgram(program);

        System.out.println("\nExecuting program...\n");
        controller.executeAllSteps();
        System.out.println("\nFinal state:");
        controller.displayCurrentState();
    }
}
